function SummaryCard({ title, value }) {
  return (
    <div className="summary-card">
      <h3>{title}</h3>
      <h1>{value}</h1>
    </div>
  );
}

export default SummaryCard;